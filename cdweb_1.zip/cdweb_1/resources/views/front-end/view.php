<?php
echo "Day la trang view ";