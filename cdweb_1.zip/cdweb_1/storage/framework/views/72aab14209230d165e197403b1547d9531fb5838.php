<?php /* D:\ProgramD\htdocs\Framew\lar\resources\views/front-end/masterpage/master.blade.php */ ?>

<?php echo $__env->make('front-end.masterpage.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>;
 
 <?php echo $__env->make('front-end.masterpage.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>