<?php /* D:\ProgramD\htdocs\Framew\lar\resources\views/front-end/add-flight.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<main>
        <div class="container">
            <section>
                <h3>Add Flight</h3>              
                <?php if(isset($mess)): ?>
                    <p class="alert"> <?php echo e($mess); ?>  </p>
                <?php endif; ?>              
                <div class="panel panel-default">
                    <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                        <form role="form" method="POST" action="<?php echo e(route('postFlight')); ?>" onsubmit="return validateForm_2();" >
                      <?php echo csrf_field(); ?>
                            <div class="row">
                            <div class="col-sm-3">
                                    <h4 class="form-heading">1. Country</h4>
                                    <div class="form-group">
                                 
                                        <label class="control-label">Country From: </label>
										<select class="form-control" name="country_from" id="country_from">
                                        <!-- // trả về giá trị cũ của option -->
											<option>---Select Country--- </option>
                                            <?php $__currentLoopData = $contry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                              
                                                <?php if(old('country_from') !=  ""): ?>                                          
                                                <option value="<?php echo e($country->country_id); ?>" selected><?php echo e($country->country_name); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($country->country_id); ?>"><?php echo e($country->country_name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

										</select>                                       
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label"> Country To: </label>
                                        <select class="form-control" name="country_to" id="country_to">
                                            <option>---Select Country--- </option>
                                            <?php $__currentLoopData = $contry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country->country_id); ?>" <?php echo (old("country_to") == $country->country_id ? "selected": ""); ?> >
                                                    <?php echo e($country->country_name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>       
                                    </div>
                                </div>
         
                                <div class="col-sm-3">
                                    <h4 class="form-heading">2. Flight Destination</h4>
                                    <div class="form-group">
                                        <label class="control-label">From: </label>
										<select class="form-control" name="from" id="from">
                                            <option>-- Select City --</option>
										</select>                                       
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">To: </label>
                                        <select class="form-control" name="to" id="to">
										    <option>-- Select City -- </option>
										</select>       
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Distance (Km): </label>
                                        <input  type="text" name="km" id="distance" class="form-control" placeholder="please enter distance (km)" >
										    
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                     <h4 class="form-heading">3. Airline</h4>
                                    <div class="form-group">
                                        <label class="control-label">Airline Name: </label>
                                        <select name="airline" id="airline" class="form-control">
                                            <option>---Chưa chọn Hãng Bay--- </option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Transit: </label>
                                        <select name="transit" class="form-control">

                                            <option value="0">0</option>
                                            <option value="1">1</option>
                                            <option value="2">2</option>
                                           
                                        </select>
                                    </div>

                                </div>
                                <div class="col-sm-3">
                                    <h4 class="form-heading">4. Date of Flight</h4>
                                    <div class="form-group">
                                        <label class="control-label">Departure: </label>
                                         <?php $date_now = date('Y-m-d\TH:i');
                                          ?>
                                        <input  type="datetime-local" name="departure" id="departure" value="<?php echo $date_now ?>" class="form-control"  class="datepicker">
                                    </div>
                            
                                    <div class="form-group" id="hide">
                                        <label class="control-label">Arrival date: </label>
                                        <input type="datetime-local" name="return" id="date_return" value="<?php echo $date_now?>" class="form-control">
                                    </div>
                                <div class="form-group">
                                        <button type="submit" name="btn_submit" class="btn btn-primary btn-block">Add Flights</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.masterpage.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>