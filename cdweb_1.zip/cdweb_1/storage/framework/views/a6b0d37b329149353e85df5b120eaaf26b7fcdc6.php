<?php /* D:\ProgramD\htdocs\Framew\lar\resources\views/front-end/form-edit-passenger.blade.php */ ?>
<?php $__env->startSection('content'); ?>
    <main>
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-push-3">
                    <h2>Edit Passenger</h2>
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <form role="form" action="<?php echo e(route('postEditPassenger')); ?>" method="post">
                            <!-- hiển thị thông báo sửa thành công -->
                            <?php if(session('status')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>
                            <input type="hidden" name="passenger_id" class="form-control" value="<?php echo e($passenger->passenger_id); ?>">
                            <?php echo csrf_field(); ?>
                                <div class="form-group">
                                <label class="control-label">Title:</label>
                                <select class="form-control" name='passenger_title'>
                                    <option value="Mr">Mr.</option>
                                    <option value="Ms">Mrs.</option>
                                </select>
                                </div>
                                <div class="form-group">
                                    <label class="control-label">First Name:</label>
                                    <input type="text" class="form-control" name ="firstName" value="<?php echo e($passenger->passenger_first_name); ?>" placeholder="Enter your name">
                                </div>
                                <div class="form-group">
                                    <label class="control-label">Last Name:</label>
                                    <input type="tel" class="form-control" name ="lastName" value="<?php echo e($passenger->passenger_last_name); ?>" placeholder="Enter your phone number">
                                </div>
                                <div class="text-right">
                                    <button type="submit" class="btn btn-primary">Edit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.masterpage.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>