<?php /* D:\ProgramD\htdocs\Framew\lar\resources\views/front-end/register.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<main>
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-push-3">
                    <h2>Join as a Wordskills Travel Member</h2>
                    <div class="panel panel-default">
                        <div class="panel-body">
                        <!-- //onsubmit="return validateForm();" -->
                        <form method="POST" action="<?php echo e(route('register')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                    <label class="control-label"><?php echo e(__('Name')); ?>:</label>
                                    <div class="">
                                    <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                        <?php if($errors->has('name')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('name')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                        <span class="help-block"></span>
                                    </div>

                                </div>
                                <div class="form-group">
                                <div> 
                                    <label class="control-label"><?php echo e(__('E-Mail Address')); ?>:</label>
                                    <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>

                                        <?php if($errors->has('email')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('email')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    <span class="help-block"></span>
                                </div>
                                </div>
                                <div class="form-group">
                                <div>
                                    <label class="control-label"><?php echo e(__('Password')); ?>:</label>
                                    <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                        <?php if($errors->has('password')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('password')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                     <span class="help-block"></span>
                                </div>
                                </div>
                                 <div class="form-group">
                                    <label class="control-label"><?php echo e(__('Confirm Password')); ?>:</label>
                                    <div class="">
                                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                                        <span class="help-block"></span>
                                     </div>
                                </div>
                                <!-- <div class="form-group">
                                    <div class=""> 
                                        <label class="control-label">Phone Number:</label>
                                        <input type="tel" name="phone" id="phone" class="form-control" placeholder="Enter your phone number" onkeyup="validatePhone()">
                                         <span class="help-block"></span>
                                    </div>
                                </div> -->
                                <div class="text-right">
                                    <button type="submit" name="btn_submit" class="btn btn-primary"><?php echo e(__('Register')); ?></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.masterpage.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>