<?php /* C:\wamp64\www\lar\resources\views/front-end/masterpage/footer.blade.php */ ?>
<footer>
        <div class="container">
            <p class="text-center">
                Copyright &copy; 2017 | All Right Reserved
            </p>
        </div>
    </footer>
</div>
<!--scripts-->
<script type="text/javascript" src=" <?php echo e(URL::asset('public/assets/jquery-3.2.1.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('public/assets/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('public/assets/myfunction.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('public/assets/myfunction-2.js')); ?>"></script>
<script>
         $(document).ready(function() {
           $('#country_from').on('change', function() {
            var countryID = $(this).val();
            if(countryID) {
                $.ajax({
                    url: 'findCityByCountry/'+countryID,
                    type: "GET",
                    data : {"_token":"<?php echo e(csrf_token()); ?>"},
                    dataType: "json",
                    success:function(data) {
                        //console.log(data);
                      if(data){
                        $('#from').empty();
                        $('#from').focus;
                        $.each(data, function(key, value){
                        $('select[name="from"]').append('<option value="'+ value.city_id +'">' + value.city_name+ '</option>');
                    });
                  }else{
                    $('#from').empty();
                  }
                  }
                });
            }else{
              $('#city').empty();
            }
        });

        // load thành phố theo nước - 2
        $('#country_to').on('change', function() {
            var countryID = $(this).val();
            if(countryID) {
                $.ajax({
                    url: 'findCityByCountry/'+countryID,
                    type: "GET",
                    data : {"_token":"<?php echo e(csrf_token()); ?>"},
                    dataType: "json",
                    success:function(data) {
                        //console.log(data);
                      if(data){
                        $('#to').empty();
                        $('#to').focus;
                        $.each(data, function(key, value){
                        $('select[name="to"]').append('<option value="'+ value.city_id +'">' + value.city_name+ '</option>');
                    });
                  }else{
                    $('#to').empty();
                  }
                  }
                });
            }else{
              $('#to').empty();
            }
        });

        // load hãng bay 
        $('#to').on('change', function() {
            var id_from = $('#country_from').val();
            var id_to   = $('#country_to').val();
            if(id_from) {
                $.ajax({
                    url: 'findAirline/'+id_from+'/'+id_to,
                    type: "GET",
                    data : {"_token":"<?php echo e(csrf_token()); ?>"},
                    dataType: "json",
                    success:function(data) {
                        //console.log(data);
                      if(data){
                        $('#airline').empty();
                        $('#airline').focus;
                        $.each(data, function(key, value){
                        $('select[name="airline"]').append('<option value="'+ value.airways_id +'">' + value.airways_name+ '</option>');
                    });
                  }else{
                    $('#airline').empty();
                  }
                  }
                });
            }else{
              $('#airline').empty();
            }
        });

                // load hãng bay  2
                $('#from').on('change', function() {
            var id_from = $('#country_from').val();
            var id_to   = $('#country_to').val();
            if(id_from) {
                $.ajax({
                    url: 'findAirline/'+id_from+'/'+id_to,
                    type: "GET",
                    data : {"_token":"<?php echo e(csrf_token()); ?>"},
                    dataType: "json",
                    success:function(data) {
                        //console.log(data);
                      if(data){
                        $('#airline').empty();
                        $('#airline').focus;
                        $.each(data, function(key, value){
                        $('select[name="airline"]').append('<option value="'+ value.airways_id +'">' + value.airways_name+ '</option>');
                    });
                  }else{
                    $('#airline').empty();
                  }
                  }
                });
            }else{
              $('#airline').empty();
            }
        });

    });


</script>
</body>
</html>